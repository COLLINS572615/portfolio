from django.shortcuts import render, redirect, get_object_or_404
from .models import Product, Cart, CartItem
from django.contrib.auth.decorators import login_required
from django.contrib import messages


def product_list(request):
    products = Product.objects.all()
    return render(request, 'store/product_list.html', {'products' : products})

def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request,'store/product_detail.html', {'product' : product} )

def get_cart(user):
    if user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user=user)
        return cart
    return None

def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id = product_id)

    #Get a cart from the session or initialize a new one
    cart = request.session.get('cart', {})

    #Add the product to the cart or update the quantity
    if str(product_id) in cart:
        cart[str(product_id)]['quantity']+=1
    else:
        cart[str(product_id)]={
            'name':product.name,
            'price':product.price,
            'quantity':'1'
        }
    
    #Save the updated cart back to the session
    request.session['cart'] = cart
    return redirect('cart_view')

def merge_carts(request, user):
    session_cart = request.session.get('cart', {})
    if session_cart:
        user_cart, _ = Cart.objects.get_or_create(user=user)
        for product_id, item in session_cart.items():
            product = get_object_or_404(Product, id=product_id)
            cart_item, created = CartItem.objects.get_or_create(cart=user_cart, product=product)
            if not created:
                cart_item.quantity += item['quantity']
            cart_item.save()

        # Clear the session cart after merging
        del request.session['cart']

@login_required
def cart_view(request):
    cart = get_cart(request.user)
    items = cart.items.all() if cart else[]
    total = sum(item.total_price for item in items)

    if request.method == "POST":
        for item in items:
            quantity = request.POST.get(f"quantity_{item.id}")
            if quantity and quantity.isdigit():
                new_quantity = int(quantity)
                if new_quantity <= items.product.stock:
                    item.quantity = new_quantity
                    item.save()

                else:
                    messages.warning(request, f"Only {item.product.stock} items in stock for {item.product.name}")
        return redirect('cart_view')
    
    return render(request, 'store/cart.html', {'items': items, 'total' : total})

@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id = product_id)
    cart = get_cart(request.user)
    if cart:
        item, created = CartItem.objects.get_or_create(cart = cart, product=product)
        if not created:
            item.quantity += 1
            item.save()
    return redirect('cart_view')

@login_required
def remove_from_cart(request, item_id):
    cart = get_cart(request.user)
    item = get_object_or_404(CartItem, id = item_id, cart = cart)
    item.delete()
    return render('cart_view')



