import requests
from bs4 import BeautifulSoup

def fetch_recipes(ingredient):
    api_key = 'c90ceee1246942a69c66f3da59ff6e98'
    url = f"https://api.spoonacular.com/recipes/findByIngredients?ingredients={ingredient}&number=10&apiKey={api_key}"
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        recipes = [{'title': r['title'], 'link': f"https://spoonacular.com/recipes/{r['id']}"} for r in data]
        print(f"Fetched {len(recipes)} recipes for ingredient '{ingredient}'")
        return recipes
    else:
        print(f"Error: {response.status_code}, {response.text}")
        return []

def get_user_ingredients():
    ingredients = input("Enter ingredients, separated by commas: ")
    return [ingredient.strip() for ingredient in ingredients.split(',')]

def find_recipes():
    ingredients = get_user_ingredients()
    all_recipes = []
    
    for ingredient in ingredients:
        print(f"Searching recipes for: {ingredient}")
        recipes = fetch_recipes(ingredient)
        if not recipes:
            print(f"No recipes found for '{ingredient}'.")
        else:
            all_recipes.extend(recipes)
    
    # Display results
    if all_recipes:
        print("\nHere are the recipes found:")
        for i, recipe in enumerate(all_recipes, 1):
            print(f"{i}. {recipe['title']}")
            print(f"   Link: {recipe['link']}")
    else:
        print("No recipes found for the provided ingredients.")

if __name__ == "__main__":
    print("Welcome to the Recipe Finder!")
    find_recipes()
